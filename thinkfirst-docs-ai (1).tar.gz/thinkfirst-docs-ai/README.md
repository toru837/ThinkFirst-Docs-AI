# 🧠 ThinkFirst Docs AI

> A document-centric AI workspace where users **think through text using AI guidance** — not AI-generated answers.

---

## What It Does

Upload a PDF or TXT document → select any text → apply an **AI Lens** → get structured thinking guidance. No chat. No chatbot. Just you, your document, and a set of analytical tools that help you think more clearly.

### AI Lenses
| Lens | What it does |
|------|-------------|
| 💡 **Explain** | Clarifies meaning, surfaces hidden implications and what's *not* being said |
| ✂️ **Simplify** | Rewrites in plain language without losing meaning |
| ⚡ **Challenge** | 3 critical questions + strongest counter-argument |
| 🔭 **Expand** | Deeper implications, alternative perspectives, hidden tensions |
| 📌 **Extract** | Key points as bullets + one implicit assumption worth questioning |

---

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **AI**: OpenAI API (`gpt-4o-mini` by default)
- **PDF Parsing**: `pdf-parse`
- **Styling**: Pure CSS with CSS variables (no Tailwind)
- **Deployment**: Vercel-ready

---

## Local Setup

### 1. Clone and install

```bash
git clone <your-repo-url>
cd thinkfirst-docs-ai
npm install
```

### 2. Configure environment

```bash
cp .env.example .env.local
```

Edit `.env.local`:
```env
OPENAI_API_KEY=sk-your-openai-api-key-here

# Optional: change model (default: gpt-4o-mini)
# OPENAI_MODEL=gpt-4o
```

Get your API key at: https://platform.openai.com/api-keys

### 3. Run development server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## Deployment on Vercel

### Option A: Deploy via Vercel CLI

```bash
npm install -g vercel
vercel
```

### Option B: Deploy via GitHub

1. Push this project to a GitHub repository
2. Go to [vercel.com](https://vercel.com) → New Project
3. Import your repository
4. Add environment variables in Vercel dashboard:
   - `OPENAI_API_KEY` = your OpenAI key
5. Click **Deploy**

### Environment Variables on Vercel

In your Vercel project dashboard → Settings → Environment Variables:

| Variable | Required | Description |
|----------|----------|-------------|
| `OPENAI_API_KEY` | ✅ Yes | Your OpenAI API key |
| `OPENAI_MODEL` | Optional | Model to use (default: `gpt-4o-mini`) |

---

## Project Structure

```
thinkfirst-docs-ai/
├── app/
│   ├── api/
│   │   ├── lens/route.ts        # AI lens processing endpoint
│   │   └── parse/route.ts       # Document parsing endpoint
│   ├── workspace/
│   │   ├── page.tsx             # Main workspace page
│   │   └── layout.tsx
│   ├── globals.css              # Global styles + design tokens
│   ├── layout.tsx               # Root layout
│   └── page.tsx                 # Upload/landing page
├── components/
│   ├── DocumentEditor.tsx       # Editable document with selection
│   ├── FloatingToolbar.tsx      # Toolbar that appears on text selection
│   ├── Header.tsx               # Top navigation bar
│   ├── LensPanel.tsx            # AI insights right panel
│   ├── NotesPanel.tsx           # Notes right panel
│   └── SectionNav.tsx           # Left section navigation
├── lib/
│   ├── lensPrompts.ts           # AI prompt engineering for each lens
│   └── textChunker.ts           # Document → sections algorithm
├── types/
│   └── index.ts                 # TypeScript types
├── .env.example                 # Environment variable template
├── next.config.js
└── package.json
```

---

## Key Design Decisions

### Why no chat interface?
The product philosophy is that AI should **scaffold thinking**, not replace it. A chat interface encourages passive consumption; inline lenses force active engagement with specific text.

### Why gpt-4o-mini by default?
Cost efficiency for document processing. For richer analysis, set `OPENAI_MODEL=gpt-4o` in your env.

### Prompt engineering approach
Each lens has a purpose-built prompt that:
- Instructs the model to **never give final answers**
- Targets specific cognitive moves (questioning assumptions, steelmanning, identifying tensions)
- Keeps responses structured, concise, and non-generic

---

## Features Checklist

- [x] PDF and TXT document upload
- [x] Automatic section chunking (heading-aware + paragraph fallback)
- [x] 5 AI lenses: Explain, Simplify, Challenge, Expand, Extract
- [x] Floating toolbar on text selection
- [x] Right-panel lens results with history
- [x] Editable document sections
- [x] Notes system (anchored to selected text)
- [x] Dark / Light mode
- [x] Notes persisted to localStorage
- [x] Section navigation sidebar
- [x] Responsive layout
- [x] Vercel deployment ready

---

## Cost Estimate

Using `gpt-4o-mini`:
- ~$0.00015 per 1K input tokens
- ~$0.0006 per 1K output tokens
- Each lens call ≈ 500–1500 tokens total ≈ **$0.001–$0.003 per click**

For a typical session (20 lens applications): **~$0.03–$0.05**

---

## License

MIT — build freely, think deeply.
