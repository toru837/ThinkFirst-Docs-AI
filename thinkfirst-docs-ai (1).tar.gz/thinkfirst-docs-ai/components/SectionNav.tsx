'use client';

import { DocumentSection } from '@/types';

interface SectionNavProps {
  sections: DocumentSection[];
  activeSectionId: string | null;
  onSelectSection: (id: string) => void;
  fileName: string;
  onNewDocument: () => void;
}

export default function SectionNav({ sections, activeSectionId, onSelectSection, fileName, onNewDocument }: SectionNavProps) {
  const shortName = fileName.replace(/\.[^.]+$/, '').replace(/[-_]/g, ' ');

  return (
    <div style={{ width: '220px', minWidth: '220px', height: '100%', borderRight: '1px solid var(--border)', background: 'var(--bg-surface)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Doc title */}
      <div style={{ padding: '16px 16px 12px', borderBottom: '1px solid var(--border-soft)' }}>
        <p style={{ fontFamily: 'var(--font-ui)', fontSize: '10px', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.09em', marginBottom: '8px' }}>Document</p>
        <p style={{ fontFamily: 'var(--font-display)', fontSize: '0.9rem', fontWeight: 600, color: 'var(--text-primary)', lineHeight: 1.3, overflow: 'hidden', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' as const }} title={shortName}>{shortName}</p>
        <p style={{ fontFamily: 'var(--font-ui)', fontSize: '11px', color: 'var(--text-muted)', marginTop: '4px' }}>{sections.length} section{sections.length !== 1 ? 's' : ''}</p>
      </div>

      {/* Section list */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '8px 0' }}>
        <p style={{ fontFamily: 'var(--font-ui)', fontSize: '10px', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.09em', padding: '8px 16px 6px' }}>Sections</p>
        {sections.map((section, idx) => {
          const isActive = section.id === activeSectionId;
          return (
            <button
              key={section.id}
              onClick={() => onSelectSection(section.id)}
              style={{
                width: '100%', textAlign: 'left', padding: '8px 16px',
                background: isActive ? 'var(--accent-dim)' : 'transparent',
                border: 'none', borderLeft: `2px solid ${isActive ? 'var(--accent)' : 'transparent'}`,
                cursor: 'pointer', transition: 'all 0.15s ease', display: 'flex', alignItems: 'flex-start', gap: '8px',
              }}
              onMouseEnter={e => { if (!isActive) { (e.currentTarget as HTMLButtonElement).style.background = 'var(--bg-hover)'; } }}
              onMouseLeave={e => { if (!isActive) { (e.currentTarget as HTMLButtonElement).style.background = 'transparent'; } }}
            >
              <span style={{ fontFamily: 'var(--font-ui)', fontSize: '10px', fontWeight: 500, color: isActive ? 'var(--accent)' : 'var(--text-muted)', marginTop: '3px', minWidth: '18px', textAlign: 'right' }}>{idx + 1}</span>
              <span style={{ fontFamily: 'var(--font-ui)', fontSize: '12.5px', fontWeight: isActive ? 500 : 400, color: isActive ? 'var(--text-accent)' : 'var(--text-secondary)', lineHeight: 1.4, overflow: 'hidden', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' as const }}>{section.title}</span>
            </button>
          );
        })}
      </div>

      {/* New document button */}
      <div style={{ padding: '12px', borderTop: '1px solid var(--border-soft)' }}>
        <button
          onClick={onNewDocument}
          style={{ width: '100%', padding: '9px', background: 'var(--bg-raised)', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--text-secondary)', fontFamily: 'var(--font-ui)', fontSize: '12.5px', fontWeight: 500, cursor: 'pointer', transition: 'all 0.15s', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--accent)'; (e.currentTarget as HTMLButtonElement).style.color = 'var(--accent)'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--border)'; (e.currentTarget as HTMLButtonElement).style.color = 'var(--text-secondary)'; }}
        >
          <span>↑</span><span>New Document</span>
        </button>
      </div>
    </div>
  );
}
