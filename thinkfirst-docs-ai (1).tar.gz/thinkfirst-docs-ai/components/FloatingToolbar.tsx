'use client';

import { LensType } from '@/types';

interface FloatingToolbarProps {
  position: { x: number; y: number } | null;
  selectedText: string;
  onLens: (lens: LensType) => void;
  onAddNote: () => void;
  isProcessing: boolean;
}

const LENSES: { type: LensType; label: string; icon: string; title: string }[] = [
  { type: 'explain', label: 'Explain', icon: '💡', title: 'Clarify meaning and hidden implications' },
  { type: 'simplify', label: 'Simplify', icon: '✂️', title: 'Rewrite in clear, plain language' },
  { type: 'challenge', label: 'Challenge', icon: '⚡', title: '3 critical questions + counter-argument' },
  { type: 'expand', label: 'Expand', icon: '🔭', title: 'Deeper insights and alternative perspectives' },
  { type: 'extract', label: 'Extract', icon: '📌', title: 'Key points as structured bullets' },
];

export default function FloatingToolbar({ position, selectedText, onLens, onAddNote, isProcessing }: FloatingToolbarProps) {
  if (!position || !selectedText.trim() || selectedText.trim().length < 5) return null;

  return (
    <div
      style={{
        position: 'fixed',
        left: position.x,
        top: position.y - 56,
        transform: 'translateX(-50%)',
        zIndex: 1000,
        display: 'flex',
        alignItems: 'center',
        gap: '2px',
        background: 'var(--toolbar-bg)',
        border: '1px solid var(--border)',
        borderRadius: '12px',
        padding: '5px',
        boxShadow: 'var(--shadow-lg)',
        animation: 'toolbarPop 0.15s ease',
        pointerEvents: 'auto',
      }}
    >
      {LENSES.map((lens, i) => (
        <ToolbarButton
          key={lens.type}
          icon={lens.icon}
          label={lens.label}
          title={lens.title}
          disabled={isProcessing}
          onClick={() => onLens(lens.type)}
          isLast={false}
        />
      ))}

      {/* Divider */}
      <div style={{ width: '1px', height: '24px', background: 'var(--border)', margin: '0 3px' }} />

      <ToolbarButton
        icon="📝"
        label="Note"
        title="Add a note to this text"
        disabled={false}
        onClick={onAddNote}
        isNote
      />

      {isProcessing && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '4px 8px', borderLeft: '1px solid var(--border)', marginLeft: '2px' }}>
          <div style={{ width: '12px', height: '12px', border: '1.5px solid var(--border)', borderTopColor: 'var(--accent)', borderRadius: '50%', animation: 'spin 0.7s linear infinite' }} />
          <span style={{ fontFamily: 'var(--font-ui)', fontSize: '11px', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>Thinking…</span>
        </div>
      )}
    </div>
  );
}

function ToolbarButton({ icon, label, title, disabled, onClick, isNote }: {
  icon: string; label: string; title: string; disabled: boolean; onClick: () => void; isNote?: boolean; isLast?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={title}
      style={{
        display: 'flex', alignItems: 'center', gap: '4px',
        padding: '5px 9px', border: 'none', borderRadius: '8px',
        background: 'transparent', color: isNote ? 'var(--text-muted)' : 'var(--text-secondary)',
        fontFamily: 'var(--font-ui)', fontSize: '12px', fontWeight: 500,
        cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.5 : 1,
        transition: 'all 0.12s ease', whiteSpace: 'nowrap',
      }}
      onMouseEnter={e => {
        if (!disabled) {
          const el = e.currentTarget as HTMLButtonElement;
          el.style.background = isNote ? 'rgba(100,100,200,0.1)' : 'var(--accent-dim)';
          el.style.color = isNote ? '#9090d0' : 'var(--text-accent)';
        }
      }}
      onMouseLeave={e => {
        const el = e.currentTarget as HTMLButtonElement;
        el.style.background = 'transparent';
        el.style.color = isNote ? 'var(--text-muted)' : 'var(--text-secondary)';
      }}
    >
      <span style={{ fontSize: '13px' }}>{icon}</span>
      <span>{label}</span>
    </button>
  );
}
