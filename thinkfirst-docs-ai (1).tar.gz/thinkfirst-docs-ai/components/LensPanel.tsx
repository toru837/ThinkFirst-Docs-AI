'use client';

import { LensResult, LensType } from '@/types';

interface LensPanelProps {
  results: LensResult[];
  active: LensResult | null;
  onSelect: (result: LensResult) => void;
  isProcessing: boolean;
}

const LENS_META: Record<LensType, { icon: string; color: string; label: string }> = {
  explain:   { icon: '💡', color: '#c9963f', label: 'Explain' },
  simplify:  { icon: '✂️', color: '#6b9e7a', label: 'Simplify' },
  challenge: { icon: '⚡', color: '#c97070', label: 'Challenge' },
  expand:    { icon: '🔭', color: '#7090c9', label: 'Expand' },
  extract:   { icon: '📌', color: '#a070c9', label: 'Extract' },
};

function formatResult(text: string): string {
  // Convert **bold** to <strong>, and newlines to <br>
  return text
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\n/g, '<br/>');
}

export default function LensPanel({ results, active, onSelect, isProcessing }: LensPanelProps) {
  if (isProcessing && results.length === 0) {
    return (
      <div style={{ padding: '24px 16px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px' }}>
        <div style={{ width: '32px', height: '32px', border: '2px solid var(--border)', borderTopColor: 'var(--accent)', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
        <p style={{ fontFamily: 'var(--font-ui)', fontSize: '12.5px', color: 'var(--text-muted)', textAlign: 'center', lineHeight: 1.5 }}>Applying lens…<br/><span style={{ fontSize: '11px' }}>Shaping your thinking</span></p>
      </div>
    );
  }

  if (results.length === 0) {
    return (
      <div style={{ padding: '24px 16px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px', opacity: 0.7 }}>
        <div style={{ fontSize: '2rem', opacity: 0.4 }}>🔎</div>
        <div style={{ textAlign: 'center' }}>
          <p style={{ fontFamily: 'var(--font-ui)', fontWeight: 500, fontSize: '12.5px', color: 'var(--text-secondary)', marginBottom: '6px' }}>No lens applied yet</p>
          <p style={{ fontFamily: 'var(--font-ui)', fontSize: '11.5px', color: 'var(--text-muted)', lineHeight: 1.5 }}>Select text in the document and choose a lens to guide your thinking.</p>
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Active result */}
      {active && (
        <div style={{ flex: 1, overflowY: 'auto', padding: '16px', borderBottom: '1px solid var(--border-soft)', animation: 'slideInRight 0.2s ease' }}>
          {/* Lens badge */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '12px' }}>
            <span style={{ fontSize: '14px' }}>{LENS_META[active.lens].icon}</span>
            <span style={{ fontFamily: 'var(--font-ui)', fontSize: '10px', fontWeight: 600, color: LENS_META[active.lens].color, textTransform: 'uppercase', letterSpacing: '0.08em' }}>{LENS_META[active.lens].label}</span>
            <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-ui)', fontSize: '10px', color: 'var(--text-muted)' }}>{new Date(active.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
          </div>

          {/* Original text */}
          <div style={{ background: 'var(--bg-raised)', border: '1px solid var(--border)', borderRadius: '8px', padding: '10px 12px', marginBottom: '14px' }}>
            <p style={{ fontFamily: 'var(--font-ui)', fontSize: '9.5px', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '5px' }}>Selected text</p>
            <p style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: 'var(--text-secondary)', fontStyle: 'italic', lineHeight: 1.6, display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical' as const, overflow: 'hidden' }}>"{active.inputText}"</p>
          </div>

          {/* AI response */}
          <div
            className="lens-result-body"
            style={{ fontFamily: 'var(--font-ui)', fontSize: '13px', color: 'var(--text-primary)', lineHeight: 1.7 }}
            dangerouslySetInnerHTML={{ __html: formatResult(active.result) }}
          />
        </div>
      )}

      {/* History list */}
      {results.length > 1 && (
        <div style={{ maxHeight: '200px', overflowY: 'auto', padding: '8px 0' }}>
          <p style={{ fontFamily: 'var(--font-ui)', fontSize: '10px', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', padding: '6px 16px' }}>History</p>
          {results.slice(1).map(result => {
            const meta = LENS_META[result.lens];
            return (
              <button
                key={result.id}
                onClick={() => onSelect(result)}
                style={{ width: '100%', textAlign: 'left', padding: '8px 16px', background: 'transparent', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px', transition: 'background 0.12s' }}
                onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'var(--bg-hover)'; }}
                onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'transparent'; }}
              >
                <span style={{ fontSize: '12px' }}>{meta.icon}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <span style={{ fontFamily: 'var(--font-ui)', fontSize: '11px', fontWeight: 500, color: meta.color }}>{meta.label} · </span>
                  <span style={{ fontFamily: 'var(--font-body)', fontSize: '11px', color: 'var(--text-muted)', fontStyle: 'italic', overflow: 'hidden', display: 'inline-block', maxWidth: '140px', verticalAlign: 'bottom', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>"{result.inputText}"</span>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {isProcessing && results.length > 0 && (
        <div style={{ padding: '10px 16px', display: 'flex', alignItems: 'center', gap: '8px', borderTop: '1px solid var(--border-soft)' }}>
          <div style={{ width: '14px', height: '14px', border: '1.5px solid var(--border)', borderTopColor: 'var(--accent)', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
          <span style={{ fontFamily: 'var(--font-ui)', fontSize: '11.5px', color: 'var(--text-muted)' }}>Processing new lens…</span>
        </div>
      )}
    </div>
  );
}
