'use client';

import { useRef, useCallback, useEffect } from 'react';
import { DocumentSection, LensType } from '@/types';
import FloatingToolbar from './FloatingToolbar';

interface DocumentEditorProps {
  sections: DocumentSection[];
  activeSectionId: string | null;
  selectedText: string;
  toolbarPosition: { x: number; y: number } | null;
  isProcessing: boolean;
  onSectionUpdate: (id: string, content: string) => void;
  onSelection: (text: string, sectionId: string, position: { x: number; y: number } | null) => void;
  onLens: (lens: LensType) => void;
  onAddNote: () => void;
}

const LENS_LABEL: Record<string, string> = {
  explain: 'Explained', simplify: 'Simplified', challenge: 'Challenged', expand: 'Expanded', extract: 'Extracted',
};

export default function DocumentEditor({
  sections, activeSectionId, selectedText, toolbarPosition, isProcessing,
  onSectionUpdate, onSelection, onLens, onAddNote,
}: DocumentEditorProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const activeSectionRef = useRef<string | null>(null);

  // Scroll to active section when it changes
  useEffect(() => {
    if (!activeSectionId || activeSectionId === activeSectionRef.current) return;
    activeSectionRef.current = activeSectionId;
    const el = document.getElementById(`section-${activeSectionId}`);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, [activeSectionId]);

  const handleMouseUp = useCallback(() => {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || !selection.toString().trim()) {
      onSelection('', '', null);
      return;
    }

    const text = selection.toString().trim();
    if (text.length < 5) { onSelection('', '', null); return; }

    // Find which section this selection belongs to
    let sectionId = '';
    let node: Node | null = selection.anchorNode;
    while (node) {
      if (node instanceof HTMLElement) {
        const sid = node.dataset?.sectionid;
        if (sid) { sectionId = sid; break; }
      }
      node = node.parentNode;
    }

    if (!sectionId) { onSelection('', '', null); return; }

    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + window.scrollY;

    onSelection(text, sectionId, { x, y });
  }, [onSelection]);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    // Don't clear selection if clicking the toolbar
    const target = e.target as HTMLElement;
    if (target.closest('[data-toolbar]')) return;
  }, []);

  return (
    <div style={{ flex: 1, height: '100%', overflowY: 'auto', position: 'relative' }} ref={containerRef} onMouseUp={handleMouseUp} onMouseDown={handleMouseDown}>
      <div style={{ maxWidth: '720px', margin: '0 auto', padding: '3rem 2.5rem 6rem' }}>
        {sections.map((section, idx) => (
          <SectionBlock
            key={section.id}
            section={section}
            isActive={section.id === activeSectionId}
            onUpdate={(content) => onSectionUpdate(section.id, content)}
          />
        ))}
      </div>

      <FloatingToolbar
        position={toolbarPosition}
        selectedText={selectedText}
        onLens={onLens}
        onAddNote={onAddNote}
        isProcessing={isProcessing}
      />
    </div>
  );
}

function SectionBlock({ section, isActive, onUpdate }: {
  section: DocumentSection;
  isActive: boolean;
  onUpdate: (content: string) => void;
}) {
  const editorRef = useRef<HTMLDivElement>(null);

  const handleBlur = () => {
    if (editorRef.current) onUpdate(editorRef.current.innerText);
  };

  const headingStyle: React.CSSProperties = {
    fontFamily: 'var(--font-display)',
    fontWeight: 600,
    color: 'var(--text-primary)',
    marginBottom: '1rem',
    lineHeight: 1.25,
    letterSpacing: '-0.01em',
  };

  return (
    <div
      id={`section-${section.id}`}
      data-sectionid={section.id}
      style={{
        marginBottom: '3.5rem',
        paddingLeft: '1.5rem',
        borderLeft: `2px solid ${isActive ? 'var(--accent)' : 'var(--border-soft)'}`,
        transition: 'border-color 0.2s ease',
        animation: 'fadeUp 0.3s ease',
      }}
    >
      {/* Section title */}
      {section.level <= 2 && (
        <h2 style={{ ...headingStyle, fontSize: section.level === 1 ? '1.8rem' : '1.35rem' }}>
          {section.title}
        </h2>
      )}

      {/* Editable content */}
      <div
        ref={editorRef}
        contentEditable
        suppressContentEditableWarning
        onBlur={handleBlur}
        data-sectionid={section.id}
        style={{
          fontFamily: 'var(--font-body)',
          fontSize: '1rem',
          lineHeight: 1.8,
          color: 'var(--text-primary)',
          outline: 'none',
          whiteSpace: 'pre-wrap',
          wordBreak: 'break-word',
          minHeight: '2em',
          transition: 'background 0.15s ease',
        }}
        onFocus={e => { (e.currentTarget as HTMLDivElement).style.background = 'var(--highlight-bg)'; (e.currentTarget as HTMLDivElement).style.borderRadius = '6px'; (e.currentTarget as HTMLDivElement).style.padding = '4px 8px'; (e.currentTarget as HTMLDivElement).style.margin = '0 -8px'; }}
        onBlurCapture={e => { (e.currentTarget as HTMLDivElement).style.background = 'transparent'; (e.currentTarget as HTMLDivElement).style.padding = '0'; (e.currentTarget as HTMLDivElement).style.margin = '0'; }}
      >
        {section.content}
      </div>

      {/* Word count */}
      <p style={{ fontFamily: 'var(--font-ui)', fontSize: '11px', color: 'var(--text-muted)', marginTop: '0.75rem' }}>
        {section.content.split(/\s+/).filter(Boolean).length} words
      </p>
    </div>
  );
}
