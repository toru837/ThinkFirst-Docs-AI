'use client';

interface HeaderProps {
  fileName: string;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  rightPanel: 'lens' | 'notes';
  onSetRightPanel: (panel: 'lens' | 'notes') => void;
  notesCount: number;
  lensCount: number;
  isProcessing: boolean;
}

export default function Header({ fileName, theme, onToggleTheme, rightPanel, onSetRightPanel, notesCount, lensCount, isProcessing }: HeaderProps) {
  const shortName = fileName.replace(/\.[^.]+$/, '').replace(/[-_]/g, ' ');

  return (
    <header style={{ height: '52px', borderBottom: '1px solid var(--border)', background: 'var(--bg-surface)', display: 'flex', alignItems: 'center', padding: '0 1.25rem', gap: '12px', flexShrink: 0, zIndex: 10 }}>
      {/* Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginRight: '8px' }}>
        <span style={{ fontSize: '1.1rem' }}>🧠</span>
        <span style={{ fontFamily: 'var(--font-display)', fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)', letterSpacing: '-0.01em' }}>ThinkFirst</span>
      </div>

      {/* Divider */}
      <div style={{ width: '1px', height: '20px', background: 'var(--border)' }} />

      {/* File name */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flex: 1, minWidth: 0 }}>
        <span style={{ fontSize: '13px' }}>📄</span>
        <span style={{ fontFamily: 'var(--font-ui)', fontSize: '13px', fontWeight: 500, color: 'var(--text-secondary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{shortName}</span>
      </div>

      {/* Processing indicator */}
      {isProcessing && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '4px 10px', background: 'var(--accent-dim)', border: '1px solid var(--accent-ring)', borderRadius: '100px' }}>
          <div style={{ width: '10px', height: '10px', border: '1.5px solid var(--border)', borderTopColor: 'var(--accent)', borderRadius: '50%', animation: 'spin 0.7s linear infinite' }} />
          <span style={{ fontFamily: 'var(--font-ui)', fontSize: '11px', color: 'var(--text-accent)', whiteSpace: 'nowrap' }}>Applying lens…</span>
        </div>
      )}

      {/* Right panel toggle */}
      <div style={{ display: 'flex', background: 'var(--bg-raised)', border: '1px solid var(--border)', borderRadius: '8px', padding: '2px', gap: '2px' }}>
        {([['lens', '🔎', `Insights (${lensCount})`], ['notes', '📝', `Notes (${notesCount})`]] as const).map(([panel, icon, label]) => (
          <button
            key={panel}
            onClick={() => onSetRightPanel(panel)}
            style={{
              padding: '4px 10px', border: 'none', borderRadius: '6px',
              background: rightPanel === panel ? 'var(--bg-active)' : 'transparent',
              color: rightPanel === panel ? 'var(--text-primary)' : 'var(--text-muted)',
              fontFamily: 'var(--font-ui)', fontSize: '11.5px', fontWeight: rightPanel === panel ? 500 : 400,
              cursor: 'pointer', transition: 'all 0.12s', display: 'flex', alignItems: 'center', gap: '4px',
            }}
          >
            <span>{icon}</span><span>{label}</span>
          </button>
        ))}
      </div>

      {/* Theme toggle */}
      <button
        onClick={onToggleTheme}
        title={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
        style={{ width: '32px', height: '32px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-raised)', border: '1px solid var(--border)', borderRadius: '8px', cursor: 'pointer', fontSize: '14px', transition: 'all 0.15s', color: 'var(--text-secondary)' }}
        onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--accent)'; }}
        onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--border)'; }}
      >
        {theme === 'dark' ? '☀' : '●'}
      </button>
    </header>
  );
}
