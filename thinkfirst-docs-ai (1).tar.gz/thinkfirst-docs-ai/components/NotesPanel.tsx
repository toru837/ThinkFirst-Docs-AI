'use client';

import { useState } from 'react';
import { Note } from '@/types';

interface NotesPanelProps {
  notes: Note[];
  selectedText: string;
  activeSectionId: string | null;
  onAddNote: (note: Omit<Note, 'id' | 'createdAt'>) => void;
  onUpdateNote: (id: string, content: string) => void;
  onDeleteNote: (id: string) => void;
  pendingNoteText: string | null;
  onClearPending: () => void;
}

export default function NotesPanel({
  notes, selectedText, activeSectionId,
  onAddNote, onUpdateNote, onDeleteNote,
  pendingNoteText, onClearPending,
}: NotesPanelProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');
  const [newContent, setNewContent] = useState('');

  const handleAddNote = () => {
    if (!newContent.trim() || !activeSectionId) return;
    onAddNote({
      sectionId: activeSectionId,
      selectedText: pendingNoteText || selectedText,
      content: newContent.trim(),
    });
    setNewContent('');
    onClearPending();
  };

  const startEdit = (note: Note) => {
    setEditingId(note.id);
    setEditContent(note.content);
  };

  const saveEdit = (id: string) => {
    if (editContent.trim()) onUpdateNote(id, editContent.trim());
    setEditingId(null);
  };

  const hasContext = !!(pendingNoteText || selectedText.trim());

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Add note area */}
      <div style={{ padding: '14px', borderBottom: '1px solid var(--border-soft)' }}>
        {hasContext && (
          <div style={{ background: 'var(--bg-raised)', border: '1px solid var(--border)', borderRadius: '6px', padding: '8px 10px', marginBottom: '10px' }}>
            <p style={{ fontFamily: 'var(--font-ui)', fontSize: '9px', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '4px' }}>Anchored to</p>
            <p style={{ fontFamily: 'var(--font-body)', fontSize: '11px', color: 'var(--text-secondary)', fontStyle: 'italic', lineHeight: 1.5, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' as const, overflow: 'hidden' }}>"{(pendingNoteText || selectedText).slice(0, 120)}"</p>
          </div>
        )}
        <textarea
          value={newContent}
          onChange={e => setNewContent(e.target.value)}
          placeholder={hasContext ? 'Write your note here…' : 'Select text in the document, then write a note…'}
          rows={3}
          style={{
            width: '100%', resize: 'none', background: 'var(--bg-surface)', border: '1px solid var(--border)',
            borderRadius: '8px', padding: '10px 12px', fontFamily: 'var(--font-ui)', fontSize: '12.5px',
            color: 'var(--text-primary)', lineHeight: 1.6, outline: 'none', transition: 'border-color 0.15s',
          }}
          onFocus={e => { (e.target as HTMLTextAreaElement).style.borderColor = 'var(--accent)'; }}
          onBlur={e => { (e.target as HTMLTextAreaElement).style.borderColor = 'var(--border)'; }}
          onKeyDown={e => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) handleAddNote(); }}
        />
        <button
          onClick={handleAddNote}
          disabled={!newContent.trim() || !activeSectionId}
          style={{
            marginTop: '8px', width: '100%', padding: '8px', background: newContent.trim() ? 'var(--accent)' : 'var(--bg-raised)',
            border: `1px solid ${newContent.trim() ? 'var(--accent)' : 'var(--border)'}`,
            borderRadius: '8px', color: newContent.trim() ? '#fff' : 'var(--text-muted)',
            fontFamily: 'var(--font-ui)', fontSize: '12px', fontWeight: 500,
            cursor: newContent.trim() ? 'pointer' : 'not-allowed', transition: 'all 0.15s',
          }}
        >
          Save Note <span style={{ opacity: 0.7, fontSize: '10px' }}>⌘↵</span>
        </button>
      </div>

      {/* Notes list */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '8px 0' }}>
        {notes.length === 0 ? (
          <div style={{ padding: '24px 16px', textAlign: 'center', opacity: 0.6 }}>
            <div style={{ fontSize: '1.8rem', marginBottom: '10px', opacity: 0.4 }}>📝</div>
            <p style={{ fontFamily: 'var(--font-ui)', fontSize: '12px', color: 'var(--text-muted)', lineHeight: 1.5 }}>Your notes will appear here. Select text and write to anchor a note.</p>
          </div>
        ) : (
          <>
            <p style={{ fontFamily: 'var(--font-ui)', fontSize: '10px', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', padding: '6px 14px' }}>{notes.length} note{notes.length !== 1 ? 's' : ''}</p>
            {notes.map(note => (
              <NoteCard
                key={note.id}
                note={note}
                isEditing={editingId === note.id}
                editContent={editContent}
                onEditContent={setEditContent}
                onStartEdit={() => startEdit(note)}
                onSaveEdit={() => saveEdit(note.id)}
                onCancelEdit={() => setEditingId(null)}
                onDelete={() => onDeleteNote(note.id)}
              />
            ))}
          </>
        )}
      </div>
    </div>
  );
}

function NoteCard({ note, isEditing, editContent, onEditContent, onStartEdit, onSaveEdit, onCancelEdit, onDelete }: {
  note: Note; isEditing: boolean; editContent: string;
  onEditContent: (v: string) => void; onStartEdit: () => void;
  onSaveEdit: () => void; onCancelEdit: () => void; onDelete: () => void;
}) {
  return (
    <div style={{ margin: '4px 10px', padding: '12px', background: 'var(--note-bg)', border: '1px solid var(--border-soft)', borderRadius: '10px', animation: 'fadeUp 0.2s ease' }}>
      {note.selectedText && (
        <div style={{ borderLeft: '2px solid var(--accent)', paddingLeft: '8px', marginBottom: '8px' }}>
          <p style={{ fontFamily: 'var(--font-body)', fontSize: '10.5px', color: 'var(--text-muted)', fontStyle: 'italic', lineHeight: 1.5, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' as const, overflow: 'hidden' }}>"{note.selectedText.slice(0, 100)}"</p>
        </div>
      )}

      {isEditing ? (
        <div>
          <textarea
            value={editContent}
            onChange={e => onEditContent(e.target.value)}
            rows={3}
            autoFocus
            style={{ width: '100%', resize: 'none', background: 'var(--bg-surface)', border: '1px solid var(--accent)', borderRadius: '6px', padding: '8px', fontFamily: 'var(--font-ui)', fontSize: '12.5px', color: 'var(--text-primary)', lineHeight: 1.6, outline: 'none' }}
          />
          <div style={{ display: 'flex', gap: '6px', marginTop: '6px' }}>
            <button onClick={onSaveEdit} style={{ flex: 1, padding: '5px', background: 'var(--accent)', border: 'none', borderRadius: '6px', color: '#fff', fontFamily: 'var(--font-ui)', fontSize: '11px', fontWeight: 500, cursor: 'pointer' }}>Save</button>
            <button onClick={onCancelEdit} style={{ flex: 1, padding: '5px', background: 'var(--bg-hover)', border: '1px solid var(--border)', borderRadius: '6px', color: 'var(--text-secondary)', fontFamily: 'var(--font-ui)', fontSize: '11px', cursor: 'pointer' }}>Cancel</button>
          </div>
        </div>
      ) : (
        <div>
          <p style={{ fontFamily: 'var(--font-ui)', fontSize: '12.5px', color: 'var(--text-primary)', lineHeight: 1.65, marginBottom: '8px', whiteSpace: 'pre-wrap' }}>{note.content}</p>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontFamily: 'var(--font-ui)', fontSize: '10px', color: 'var(--text-muted)' }}>{new Date(note.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            <div style={{ display: 'flex', gap: '4px' }}>
              <IconBtn onClick={onStartEdit} title="Edit" icon="✏" />
              <IconBtn onClick={onDelete} title="Delete" icon="✕" danger />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function IconBtn({ onClick, title, icon, danger }: { onClick: () => void; title: string; icon: string; danger?: boolean }) {
  return (
    <button
      onClick={onClick} title={title}
      style={{ width: '22px', height: '22px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'transparent', border: 'none', borderRadius: '4px', color: danger ? '#c97070' : 'var(--text-muted)', fontSize: '11px', cursor: 'pointer', transition: 'all 0.12s' }}
      onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = danger ? 'rgba(201,112,112,0.1)' : 'var(--bg-hover)'; }}
      onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'transparent'; }}
    >
      {icon}
    </button>
  );
}
