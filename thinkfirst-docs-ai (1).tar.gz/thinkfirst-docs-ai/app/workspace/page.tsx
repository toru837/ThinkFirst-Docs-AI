'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { DocumentSection, LensType, LensResult, Note, WorkspaceState } from '@/types';
import Header from '@/components/Header';
import SectionNav from '@/components/SectionNav';
import DocumentEditor from '@/components/DocumentEditor';
import LensPanel from '@/components/LensPanel';
import NotesPanel from '@/components/NotesPanel';

const NOTES_KEY = 'tf-notes';
const THEME_KEY = 'tf-theme';

function generateId() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

export default function WorkspacePage() {
  const router = useRouter();
  const [state, setState] = useState<WorkspaceState>({
    fileName: '',
    sections: [],
    activeSectionId: null,
    selection: { text: '', sectionId: '', position: null },
    lensResults: [],
    activeLensResult: null,
    notes: [],
    isProcessing: false,
    theme: 'dark',
    rightPanel: 'lens',
  });
  const [pendingNoteText, setPendingNoteText] = useState<string | null>(null);
  const [loaded, setLoaded] = useState(false);
  const clickOutsideRef = useRef<boolean>(false);

  // Load document from sessionStorage on mount
  useEffect(() => {
    const raw = sessionStorage.getItem('tf-document');
    if (!raw) { router.replace('/'); return; }

    try {
      const doc = JSON.parse(raw) as { fileName: string; sections: DocumentSection[] };
      const savedNotes = JSON.parse(localStorage.getItem(NOTES_KEY) || '[]') as Note[];
      const savedTheme = (localStorage.getItem(THEME_KEY) as 'dark' | 'light') || 'dark';

      document.documentElement.setAttribute('data-theme', savedTheme);

      setState(prev => ({
        ...prev,
        fileName: doc.fileName,
        sections: doc.sections,
        activeSectionId: doc.sections[0]?.id ?? null,
        notes: savedNotes,
        theme: savedTheme,
      }));
      setLoaded(true);
    } catch {
      router.replace('/');
    }
  }, [router]);

  // Persist notes
  useEffect(() => {
    if (loaded) localStorage.setItem(NOTES_KEY, JSON.stringify(state.notes));
  }, [state.notes, loaded]);

  // Click outside to clear selection
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('[data-sectionid]') && !target.closest('[data-toolbar]')) {
        setState(prev => ({ ...prev, selection: { text: '', sectionId: '', position: null } }));
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleToggleTheme = useCallback(() => {
    setState(prev => {
      const next = prev.theme === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', next);
      localStorage.setItem(THEME_KEY, next);
      return { ...prev, theme: next };
    });
  }, []);

  const handleSectionUpdate = useCallback((id: string, content: string) => {
    setState(prev => ({
      ...prev,
      sections: prev.sections.map(s => s.id === id ? { ...s, content } : s),
    }));
  }, []);

  const handleSelection = useCallback((text: string, sectionId: string, position: { x: number; y: number } | null) => {
    setState(prev => ({ ...prev, selection: { text, sectionId, position }, activeSectionId: sectionId || prev.activeSectionId }));
  }, []);

  const handleLens = useCallback(async (lens: LensType) => {
    const { text, sectionId } = state.selection;
    if (!text.trim() || state.isProcessing) return;

    const section = state.sections.find(s => s.id === sectionId);
    const context = section?.content;

    setState(prev => ({ ...prev, isProcessing: true, rightPanel: 'lens' }));

    try {
      const res = await fetch('/api/lens', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, lens, context }),
      });
      const data = await res.json();

      if (!res.ok) throw new Error(data.error || 'Lens failed');

      const result: LensResult = {
        id: generateId(),
        lens,
        inputText: text,
        result: data.result,
        sectionId,
        timestamp: Date.now(),
      };

      setState(prev => ({
        ...prev,
        lensResults: [result, ...prev.lensResults],
        activeLensResult: result,
        isProcessing: false,
        selection: { ...prev.selection, position: null }, // hide toolbar
      }));
    } catch (err) {
      console.error(err);
      setState(prev => ({ ...prev, isProcessing: false }));
    }
  }, [state.selection, state.isProcessing, state.sections]);

  const handleAddNoteFromToolbar = useCallback(() => {
    setPendingNoteText(state.selection.text);
    setState(prev => ({
      ...prev,
      rightPanel: 'notes',
      selection: { ...prev.selection, position: null },
    }));
  }, [state.selection.text]);

  const handleAddNote = useCallback((note: Omit<Note, 'id' | 'createdAt'>) => {
    const newNote: Note = { ...note, id: generateId(), createdAt: Date.now() };
    setState(prev => ({ ...prev, notes: [newNote, ...prev.notes] }));
    setPendingNoteText(null);
  }, []);

  const handleUpdateNote = useCallback((id: string, content: string) => {
    setState(prev => ({ ...prev, notes: prev.notes.map(n => n.id === id ? { ...n, content } : n) }));
  }, []);

  const handleDeleteNote = useCallback((id: string) => {
    setState(prev => ({ ...prev, notes: prev.notes.filter(n => n.id !== id) }));
  }, []);

  const handleSelectSection = useCallback((id: string) => {
    setState(prev => ({ ...prev, activeSectionId: id }));
  }, []);

  const handleSelectLensResult = useCallback((result: LensResult) => {
    setState(prev => ({
      ...prev,
      activeLensResult: result,
      lensResults: [result, ...prev.lensResults.filter(r => r.id !== result.id)],
    }));
  }, []);

  if (!loaded) {
    return (
      <div style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-base)', flexDirection: 'column', gap: '16px' }}>
        <div style={{ width: '40px', height: '40px', border: '2px solid var(--border)', borderTopColor: 'var(--accent)', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
        <p style={{ fontFamily: 'var(--font-ui)', fontSize: '13px', color: 'var(--text-muted)' }}>Loading workspace…</p>
      </div>
    );
  }

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', background: 'var(--bg-base)', overflow: 'hidden' }}>
      <Header
        fileName={state.fileName}
        theme={state.theme}
        onToggleTheme={handleToggleTheme}
        rightPanel={state.rightPanel}
        onSetRightPanel={(panel) => setState(prev => ({ ...prev, rightPanel: panel }))}
        notesCount={state.notes.length}
        lensCount={state.lensResults.length}
        isProcessing={state.isProcessing}
      />

      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        {/* Left navigation sidebar */}
        <SectionNav
          sections={state.sections}
          activeSectionId={state.activeSectionId}
          onSelectSection={handleSelectSection}
          fileName={state.fileName}
          onNewDocument={() => { sessionStorage.removeItem('tf-document'); router.push('/'); }}
        />

        {/* Document editor — ~80% */}
        <div style={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
          <DocumentEditor
            sections={state.sections}
            activeSectionId={state.activeSectionId}
            selectedText={state.selection.text}
            toolbarPosition={state.selection.position}
            isProcessing={state.isProcessing}
            onSectionUpdate={handleSectionUpdate}
            onSelection={handleSelection}
            onLens={handleLens}
            onAddNote={handleAddNoteFromToolbar}
          />
        </div>

        {/* Right panel — ~20% */}
        <div style={{ width: '280px', minWidth: '280px', height: '100%', borderLeft: '1px solid var(--border)', background: 'var(--bg-surface)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          {/* Panel header */}
          <div style={{ padding: '12px 14px 10px', borderBottom: '1px solid var(--border-soft)', flexShrink: 0 }}>
            <p style={{ fontFamily: 'var(--font-ui)', fontSize: '10px', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.09em' }}>
              {state.rightPanel === 'lens' ? '🔎 AI Insights' : '📝 Notes'}
            </p>
          </div>

          {/* Panel content */}
          <div style={{ flex: 1, overflowY: 'auto' }}>
            {state.rightPanel === 'lens' ? (
              <LensPanel
                results={state.lensResults}
                active={state.activeLensResult}
                onSelect={handleSelectLensResult}
                isProcessing={state.isProcessing}
              />
            ) : (
              <NotesPanel
                notes={state.notes}
                selectedText={state.selection.text}
                activeSectionId={state.activeSectionId}
                onAddNote={handleAddNote}
                onUpdateNote={handleUpdateNote}
                onDeleteNote={handleDeleteNote}
                pendingNoteText={pendingNoteText}
                onClearPending={() => setPendingNoteText(null)}
              />
            )}
          </div>

          {/* Bottom status bar */}
          <div style={{ padding: '8px 14px', borderTop: '1px solid var(--border-soft)', flexShrink: 0 }}>
            <p style={{ fontFamily: 'var(--font-ui)', fontSize: '10px', color: 'var(--text-muted)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span>{state.sections.length} sections</span>
              <span>{state.notes.length} notes · {state.lensResults.length} insights</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
