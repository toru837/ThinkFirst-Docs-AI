'use client';

import { useState, useCallback, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { DocumentSection } from '@/types';

export default function HomePage() {
  const router = useRouter();
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState('');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  useEffect(() => {
    const saved = localStorage.getItem('tf-theme') as 'dark' | 'light' | null;
    if (saved) { setTheme(saved); document.documentElement.setAttribute('data-theme', saved); }
  }, []);

  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('tf-theme', next);
  };

  const processFile = useCallback(async (file: File) => {
    setError('');
    setIsUploading(true);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const res = await fetch('/api/parse', { method: 'POST', body: formData });
      const data = await res.json();

      if (!res.ok) { setError(data.error || 'Failed to parse document'); return; }

      sessionStorage.setItem('tf-document', JSON.stringify({
        fileName: data.fileName,
        sections: data.sections as DocumentSection[],
      }));

      router.push('/workspace');
    } catch {
      setError('Something went wrong. Please try again.');
    } finally {
      setIsUploading(false);
    }
  }, [router]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
  }, [processFile]);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-base)', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <header style={{ padding: '1.25rem 2rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--border)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <span style={{ fontSize: '1.35rem' }}>🧠</span>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', fontWeight: 600, color: 'var(--text-primary)', letterSpacing: '-0.01em' }}>ThinkFirst</span>
        </div>
        <button onClick={toggleTheme} style={{ background: 'none', border: '1px solid var(--border)', borderRadius: '8px', padding: '6px 12px', color: 'var(--text-secondary)', fontFamily: 'var(--font-ui)', fontSize: '13px', cursor: 'pointer', transition: 'all 0.2s' }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--accent)'; (e.currentTarget as HTMLButtonElement).style.color = 'var(--accent)'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--border)'; (e.currentTarget as HTMLButtonElement).style.color = 'var(--text-secondary)'; }}>
          {theme === 'dark' ? '☀ Light' : '● Dark'}
        </button>
      </header>

      {/* Hero */}
      <main style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '4rem 2rem', maxWidth: '680px', margin: '0 auto', width: '100%', animation: 'fadeUp 0.5s ease' }}>
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <div style={{ display: 'inline-block', background: 'var(--accent-dim)', border: '1px solid var(--accent-ring)', borderRadius: '100px', padding: '5px 14px', marginBottom: '1.5rem' }}>
            <span style={{ fontFamily: 'var(--font-ui)', fontSize: '11.5px', fontWeight: 500, color: 'var(--text-accent)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>AI-Powered Thinking Workspace</span>
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(2.2rem, 5vw, 3.4rem)', fontWeight: 700, lineHeight: 1.15, color: 'var(--text-primary)', marginBottom: '1.2rem', letterSpacing: '-0.02em' }}>
            Think deeper.<br />
            <em style={{ fontWeight: 400, color: 'var(--text-accent)' }}>Not faster.</em>
          </h1>
          <p style={{ fontFamily: 'var(--font-body)', fontSize: '1.05rem', lineHeight: 1.75, color: 'var(--text-secondary)', maxWidth: '480px', margin: '0 auto' }}>
            Upload a document. Select text. Apply AI lenses that guide your thinking — not replace it. No chatbot. Just you and the text.
          </p>
        </div>

        {/* Upload Zone */}
        <div
          onDragEnter={e => { e.preventDefault(); setIsDragging(true); }}
          onDragLeave={e => { e.preventDefault(); setIsDragging(false); }}
          onDragOver={e => e.preventDefault()}
          onDrop={handleDrop}
          onClick={() => !isUploading && document.getElementById('file-input')?.click()}
          style={{
            width: '100%', border: `1.5px dashed ${isDragging ? 'var(--accent)' : 'var(--border)'}`,
            borderRadius: '16px', padding: '3.5rem 2rem', textAlign: 'center',
            cursor: isUploading ? 'default' : 'pointer',
            background: isDragging ? 'var(--accent-dim)' : 'var(--bg-surface)',
            transition: 'all 0.2s ease', position: 'relative', overflow: 'hidden',
          }}
          onMouseEnter={e => { if (!isUploading) { (e.currentTarget as HTMLDivElement).style.borderColor = 'var(--accent)'; (e.currentTarget as HTMLDivElement).style.background = 'var(--highlight-bg)'; } }}
          onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.borderColor = isDragging ? 'var(--accent)' : 'var(--border)'; (e.currentTarget as HTMLDivElement).style.background = 'var(--bg-surface)'; }}
        >
          {isUploading ? (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px' }}>
              <div style={{ width: '40px', height: '40px', border: '2px solid var(--border)', borderTopColor: 'var(--accent)', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
              <p style={{ fontFamily: 'var(--font-ui)', fontSize: '0.9rem', color: 'var(--text-secondary)' }}>Parsing document…</p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '14px' }}>
              <div style={{ fontSize: '2.5rem', opacity: 0.7 }}>📄</div>
              <div>
                <p style={{ fontFamily: 'var(--font-ui)', fontWeight: 500, fontSize: '1rem', color: 'var(--text-primary)', marginBottom: '6px' }}>Drop your document here</p>
                <p style={{ fontFamily: 'var(--font-ui)', fontSize: '0.85rem', color: 'var(--text-muted)' }}>or click to browse · PDF and TXT supported · max 10MB</p>
              </div>
              <div style={{ display: 'flex', gap: '8px', marginTop: '4px' }}>
                {['PDF', 'TXT', 'MD'].map(f => (
                  <span key={f} style={{ fontFamily: 'var(--font-ui)', fontSize: '11px', fontWeight: 500, color: 'var(--text-muted)', background: 'var(--bg-raised)', border: '1px solid var(--border)', borderRadius: '6px', padding: '3px 10px', letterSpacing: '0.04em' }}>{f}</span>
                ))}
              </div>
            </div>
          )}
          <input id="file-input" type="file" accept=".pdf,.txt,.md" onChange={handleFileInput} style={{ display: 'none' }} />
        </div>

        {error && (
          <div style={{ marginTop: '1rem', padding: '12px 16px', background: 'rgba(220,50,50,0.08)', border: '1px solid rgba(220,50,50,0.25)', borderRadius: '10px', width: '100%' }}>
            <p style={{ fontFamily: 'var(--font-ui)', fontSize: '0.85rem', color: '#e05555', margin: 0 }}>⚠ {error}</p>
          </div>
        )}

        {/* Lens pills */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginTop: '2.5rem', justifyContent: 'center' }}>
          {[
            { icon: '💡', label: 'Explain' }, { icon: '✂️', label: 'Simplify' },
            { icon: '⚡', label: 'Challenge' }, { icon: '🔭', label: 'Expand' }, { icon: '📌', label: 'Extract' },
          ].map(l => (
            <div key={l.label} style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '6px 14px', background: 'var(--bg-raised)', border: '1px solid var(--border)', borderRadius: '100px', fontFamily: 'var(--font-ui)', fontSize: '12.5px', color: 'var(--text-secondary)', fontWeight: 500 }}>
              <span>{l.icon}</span><span>{l.label}</span>
            </div>
          ))}
        </div>
        <p style={{ fontFamily: 'var(--font-ui)', fontSize: '12px', color: 'var(--text-muted)', marginTop: '1.2rem', textAlign: 'center' }}>Select any text in your document → apply a lens → refine your thinking</p>
      </main>

      <footer style={{ padding: '1.5rem 2rem', textAlign: 'center', borderTop: '1px solid var(--border-soft)' }}>
        <p style={{ fontFamily: 'var(--font-ui)', fontSize: '12px', color: 'var(--text-muted)' }}>ThinkFirst Docs AI · Built for thinkers, not typists</p>
      </footer>
    </div>
  );
}
