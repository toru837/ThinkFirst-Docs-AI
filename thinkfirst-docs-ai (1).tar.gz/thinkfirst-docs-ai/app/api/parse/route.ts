import { NextRequest, NextResponse } from 'next/server';
import { chunkText } from '@/lib/textChunker';

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File | null;

    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 });
    }

    const MAX_SIZE = 10 * 1024 * 1024; // 10MB
    if (file.size > MAX_SIZE) {
      return NextResponse.json({ error: 'File too large (max 10MB)' }, { status: 400 });
    }

    let extractedText = '';

    if (file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')) {
      const buffer = Buffer.from(await file.arrayBuffer());
      // Dynamic import to avoid bundling issues
      const pdfParse = (await import('pdf-parse')).default;
      const data = await pdfParse(buffer);
      extractedText = data.text;
    } else if (
      file.type === 'text/plain' ||
      file.name.toLowerCase().endsWith('.txt') ||
      file.name.toLowerCase().endsWith('.md')
    ) {
      extractedText = await file.text();
    } else {
      return NextResponse.json(
        { error: 'Unsupported file type. Please upload a PDF or TXT file.' },
        { status: 400 }
      );
    }

    if (!extractedText.trim()) {
      return NextResponse.json(
        { error: 'No text could be extracted from this file.' },
        { status: 422 }
      );
    }

    const sections = chunkText(extractedText, file.name);

    if (sections.length === 0) {
      return NextResponse.json(
        { error: 'Could not parse document into sections.' },
        { status: 422 }
      );
    }

    return NextResponse.json({
      fileName: file.name,
      sections,
      totalSections: sections.length,
      totalChars: extractedText.length,
    });
  } catch (error: unknown) {
    console.error('[parse API]', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json({ error: `Parsing failed: ${message}` }, { status: 500 });
  }
}
