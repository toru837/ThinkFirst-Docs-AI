import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';
import { getLensPrompt, SYSTEM_PROMPT } from '@/lib/lensPrompts';
import { LensType } from '@/types';

// Lazy init — avoids build-time crash when OPENAI_API_KEY is not set
let _openai: OpenAI | null = null;
function getOpenAI(): OpenAI {
  if (!_openai) {
    _openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY ?? '' });
  }
  return _openai;
}

const MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';

export async function POST(request: NextRequest) {
  if (!process.env.OPENAI_API_KEY) {
    return NextResponse.json(
      { error: 'OpenAI API key not configured. Add OPENAI_API_KEY to .env.local' },
      { status: 500 }
    );
  }

  try {
    const body = await request.json();
    const { text, lens, context } = body as {
      text: string;
      lens: LensType;
      context?: string;
    };

    if (!text?.trim()) {
      return NextResponse.json({ error: 'No text provided' }, { status: 400 });
    }

    const validLenses: LensType[] = ['explain', 'simplify', 'challenge', 'expand', 'extract'];
    if (!validLenses.includes(lens)) {
      return NextResponse.json({ error: 'Invalid lens type' }, { status: 400 });
    }

    if (text.length > 4000) {
      return NextResponse.json({ error: 'Selected text too long (max 4000 chars)' }, { status: 400 });
    }

    const userPrompt = getLensPrompt(lens, text, context);

    const completion = await getOpenAI().chat.completions.create({
      model: MODEL,
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: userPrompt },
      ],
      max_tokens: 700,
      temperature: 0.72,
    });

    const result = completion.choices[0]?.message?.content ?? '';
    const tokensUsed = completion.usage?.total_tokens ?? 0;

    return NextResponse.json({ result, tokensUsed });
  } catch (error: unknown) {
    console.error('[lens API]', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json({ error: `Failed to process: ${message}` }, { status: 500 });
  }
}
