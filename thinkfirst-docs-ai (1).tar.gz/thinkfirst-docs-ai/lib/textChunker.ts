import { DocumentSection } from '@/types';

function createTitle(text: string, fallback: string): string {
  const cleaned = text.replace(/^#+\s*/, '').trim();
  if (cleaned.length <= 60) return cleaned;
  const words = cleaned.split(/\s+/).slice(0, 8).join(' ');
  return words + '…';
}

function isHeadingLine(line: string, nextLine?: string): boolean {
  if (/^#{1,6}\s+\S/.test(line)) return true;
  if (line.length < 70 && /^[A-Z0-9]/.test(line) && !line.endsWith('.') && !line.endsWith(',') && !line.endsWith(';') && line === line.trimEnd() && nextLine !== undefined && nextLine.trim() === '') return true;
  if (/^[A-Z\s\d:]{5,60}$/.test(line.trim()) && line.trim().length > 4) return true;
  return false;
}

export function chunkText(rawText: string, fileName: string): DocumentSection[] {
  const sections: DocumentSection[] = [];
  let idx = 0;

  const text = rawText
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .replace(/\f/g, '\n\n')
    .replace(/\n{4,}/g, '\n\n\n')
    .trim();

  const lines = text.split('\n');
  let currentTitle = '';
  let currentContent: string[] = [];
  let currentLevel = 3;

  function flush() {
    const content = currentContent.join('\n').replace(/\n{3,}/g, '\n\n').trim();
    if (content.length > 40) {
      sections.push({
        id: `section-${idx++}`,
        title: currentTitle || createTitle(content, `Section ${idx}`),
        content,
        level: currentLevel,
      });
    }
    currentContent = [];
  }

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();
    const nextTrimmed = lines[i + 1]?.trim() ?? '';

    if (!trimmed) {
      currentContent.push('');
      continue;
    }

    if (isHeadingLine(trimmed, nextTrimmed)) {
      flush();
      const level = /^(#{1,6})\s/.exec(trimmed)?.[1]?.length ?? 2;
      currentTitle = trimmed.replace(/^#+\s*/, '').trim();
      currentLevel = Math.min(level, 2);
    } else {
      currentContent.push(line);
    }
  }
  flush();

  // If no structure found, split by double newlines (paragraphs)
  if (sections.length <= 1) {
    sections.length = 0;
    idx = 0;
    const paras = text.split(/\n\n+/).filter(p => p.trim().length > 60);
    paras.forEach((para, i) => {
      const words = para.trim().split(/\s+/);
      const title = words.slice(0, 7).join(' ') + (words.length > 7 ? '…' : '');
      sections.push({
        id: `section-${i}`,
        title,
        content: para.trim(),
        level: 3,
      });
    });
  }

  // Absolute fallback
  if (sections.length === 0) {
    sections.push({
      id: 'section-0',
      title: fileName.replace(/\.[^.]+$/, '').replace(/[-_]/g, ' '),
      content: text,
      level: 1,
    });
  }

  return sections;
}
