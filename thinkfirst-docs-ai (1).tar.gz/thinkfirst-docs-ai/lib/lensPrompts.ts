import { LensType } from '@/types';

const SYSTEM_PROMPT = `You are ThinkFirst — a rigorous thinking coach embedded in a document workspace.

Your purpose: help users think more clearly and deeply — NOT to think for them.

Core rules:
- NEVER give final answers or complete solutions
- ALWAYS leave the hard thinking work to the user
- Be analytical, specific, and concise — never generic or vague
- Use the text's own language and concepts when possible
- Challenge assumptions, not just surface content
- Tone: direct, intellectually honest, thought-provoking

Format your response with clear structure. Use **bold** for key terms. Keep responses under 350 words.`;

const LENS_PROMPTS: Record<LensType, (text: string, context?: string) => string> = {
  explain: (text, context) => `Clarify what the following text is actually saying.

Focus on:
- The core claim or argument being made
- What might not be immediately obvious
- Any implicit assumptions embedded in the phrasing
- What this text is NOT saying (equally important)

Be concise (4–6 sentences). Do not paraphrase word-for-word.${context ? `\n\nDocument context (for reference only): "${context.slice(0, 300)}"` : ''}

Text to explain:
"${text}"`,

  simplify: (text, context) => `Rewrite the following text in clearer, simpler language — without losing any meaning.

Rules:
- Shorter sentences
- Replace jargon with plain language
- Keep all key ideas intact
- Do not add opinions or new content
- Preserve the author's original intent${context ? `\n\nContext: "${context.slice(0, 200)}"` : ''}

Text to simplify:
"${text}"`,

  challenge: (text, context) => `Generate 3 probing questions and 1 strong counter-argument for the following text.

For each question:
- Target a specific assumption, evidence gap, or logical leap
- Make it specific to THIS text (not a generic critical thinking question)
- Phrase it to make the reader genuinely think, not just confirm they read it

For the counter-argument:
- Present the strongest possible objection to the text's central claim
- Be intellectually honest — steelman the opposite view

Format exactly as:
**Critical Questions:**
1. [Question]
2. [Question]
3. [Question]

**Counter-Argument:**
[Strongest objection in 2–3 sentences]${context ? `\n\nContext: "${context.slice(0, 200)}"` : ''}

Text to challenge:
"${text}"`,

  expand: (text, context) => `Expand the thinking on the following text.

Provide:
1. **Deeper Implication** — What does this text suggest that isn't stated directly?
2. **Alternative Lens** — How would someone from a different field or discipline interpret this?
3. **Hidden Tension** — What internal contradiction or unresolved tension exists in this idea?
4. **One Question to Sit With** — A single question the reader should genuinely wrestle with

Do NOT summarize the original text. Build outward from it.${context ? `\n\nContext: "${context.slice(0, 200)}"` : ''}

Text to expand:
"${text}"`,

  extract: (text, context) => `Extract the key points from the following text.

Rules:
- 3–6 bullet points maximum
- Each point must be a DISTINCT idea (no repetition, no overlap)
- Lead with the most important insight
- Be specific — no vague statements
- If two points contradict each other, note the tension explicitly
- End with: "**Worth questioning:** [one assumption the author makes]"${context ? `\n\nContext: "${context.slice(0, 200)}"` : ''}

Text to extract from:
"${text}"`,
};

export function getLensPrompt(lens: LensType, text: string, context?: string): string {
  return LENS_PROMPTS[lens](text, context);
}

export { SYSTEM_PROMPT };
