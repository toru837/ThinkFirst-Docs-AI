export type LensType = 'explain' | 'simplify' | 'challenge' | 'expand' | 'extract';

export interface DocumentSection {
  id: string;
  title: string;
  content: string;
  level: number; // 1=heading, 2=subheading, 3=paragraph
}

export interface Note {
  id: string;
  sectionId: string;
  selectedText: string;
  content: string;
  createdAt: number;
}

export interface LensResult {
  id: string;
  lens: LensType;
  inputText: string;
  result: string;
  sectionId: string;
  timestamp: number;
}

export interface SelectionState {
  text: string;
  sectionId: string;
  position: { x: number; y: number } | null;
}

export interface WorkspaceState {
  fileName: string;
  sections: DocumentSection[];
  activeSectionId: string | null;
  selection: SelectionState;
  lensResults: LensResult[];
  activeLensResult: LensResult | null;
  notes: Note[];
  isProcessing: boolean;
  theme: 'dark' | 'light';
  rightPanel: 'lens' | 'notes';
}
